package com.example.demo.service;

import com.example.demo.entity.Product;

import java.util.List;
import java.util.Optional;

public interface ProductService {

    List<Product> getProducts();
    Product addProduct(Product product);
    Optional<Product> getProductById(Long id);

}
