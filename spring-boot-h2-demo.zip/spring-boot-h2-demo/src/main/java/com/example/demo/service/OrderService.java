package com.example.demo.service;

import com.example.demo.entity.Order;

import java.util.List;

public interface OrderService {

    Order createOrder(Order order);
    List<Order> getOrders();
    List<Order> getOrdersByProductId(Long productId);
}
