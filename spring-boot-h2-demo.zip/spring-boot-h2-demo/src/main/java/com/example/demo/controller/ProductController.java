package com.example.demo.controller;

import com.example.demo.entity.Product;
import com.example.demo.service.ProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    private static final Logger log =
            LoggerFactory.getLogger(ProductController.class);

    @Autowired
    ProductService productService;

    @GetMapping(path = "/getProducts", name = "getProducts")
    public ResponseEntity<List<Product>> getProducts() {
        log.info("Fetching all products");
        return ResponseEntity.ok(productService.getProducts());
    }

    @PostMapping(path = "/addProduct", name = "addProduct")
    public ResponseEntity<Product> addProduct(@RequestBody Product product) {
        Product saved = productService.addProduct(product);
        log.info("Product Added");
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(saved);
    }
}
