INSERT INTO products (name, price) VALUES ('MacBook', 1200.00);
INSERT INTO products (name, price) VALUES ('Chromebook', 800.00);
