import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../product.service';
import { Product } from '../product.model';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './product-list.html'
})
export class ProductListComponent implements OnInit {

  products: Product[] = [];
  productName = '';
  loading = false;
  error?: string;

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts(): void {
    this.loading = true;
    this.error = undefined;

    this.productService.getProducts().subscribe({
      next: data => {
        this.products = data;
        this.loading = false;
      },
      error: err => {
        console.error(err);
        this.error = 'Failed to load products';
        this.loading = false;
      }
    });
  }


  addProduct(): void {
    if (!this.productName.trim()) return;

    this.productService.addProduct(this.productName).subscribe({
      next: () => {
        this.productName = '';
        this.loadProducts();
      },
      error: (err: unknown) => console.error(err)
    });
  }
}
